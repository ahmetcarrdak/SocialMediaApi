create function update_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.UpdatedAt = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

alter function update_timestamp() owner to postgres;

